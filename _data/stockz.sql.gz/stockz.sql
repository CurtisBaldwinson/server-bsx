-- phpMyAdmin SQL Dump
-- version 4.4.14.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Apr 18, 2016 at 12:38 AM
-- Server version: 5.6.21
-- PHP Version: 5.6.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `stockz`
--

-- --------------------------------------------------------

--
-- Table structure for table `candidates`
--

DROP TABLE IF EXISTS `candidates`;
CREATE TABLE IF NOT EXISTS `candidates` (
  `code` varchar(4) NOT NULL DEFAULT '',
  `name` varchar(32) DEFAULT NULL,
  `category` varchar(1) DEFAULT NULL,
  `value` int(3) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `candidates`
--

INSERT INTO `candidates` (`code`, `name`, `category`, `value`) VALUES
('APPL', 'Apple', 'A', 100),
('BOND', 'Bonds', 'B', 66),
('BP', 'Believable Products', 'C', 100),
('COFF', 'Coffee', 'C', 100),
('DHS', 'Donut Hole Syndicate', 'C', 100),
('DSC', 'Deathstar Construction', 'C', 100),
('EBD', 'Environmental Bio Diversity', 'C', 100),
('FBN', 'Fly-by-Night Business Network', 'C', 100),
('GMC', 'General Motors', 'A', 100),
('GOLD', 'Gold', 'B', 110),
('GOOG', 'Google', 'A', 100),
('GRAN', 'Grain', 'B', 113),
('HD', 'Harley Davidson', 'A', 100),
('IBM', 'IBM', 'A', 100),
('IND', 'Industrial', 'B', 39),
('IXP', 'Inter-planetary Exploration Proj', 'C', 100),
('MLM', 'Moonlight madness', 'C', 100),
('MSFT', 'Microsoft', 'A', 100),
('OIL', 'Oil', 'B', 52),
('PONZ', 'Ponzi Schemes R Us', 'C', 100),
('RUN', 'Rich Uncle', 'C', 100),
('SFA', 'Star Fleet Academy', 'C', 100),
('SMV', 'Smoke & Mirrors Ventures', 'C', 100),
('SSO', 'Sleezy Snake Oil Sales', 'C', 100),
('TECH', 'Technology', 'B', 37),
('TEL', 'Telus', 'A', 100);

-- --------------------------------------------------------

--
-- Table structure for table `certificates`
--

DROP TABLE IF EXISTS `certificates`;
CREATE TABLE IF NOT EXISTS `certificates` (
  `token` varchar(8) NOT NULL,
  `stock` varchar(4) NOT NULL,
  `agent` varchar(4) NOT NULL,
  `player` varchar(64) NOT NULL,
  `amount` int(11) NOT NULL,
  `datetime` varchar(19) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `movement`
--

DROP TABLE IF EXISTS `movement`;
CREATE TABLE IF NOT EXISTS `movement` (
  `seq` int(11) NOT NULL,
  `datetime` varchar(19) DEFAULT NULL,
  `code` varchar(4) DEFAULT NULL,
  `action` varchar(4) DEFAULT NULL,
  `amount` int(2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `players`
--

DROP TABLE IF EXISTS `players`;
CREATE TABLE IF NOT EXISTS `players` (
  `seq` int(11) NOT NULL,
  `agent` varchar(4) NOT NULL,
  `player` varchar(32) NOT NULL,
  `cash` int(11) NOT NULL,
  `round` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `properties`
--

DROP TABLE IF EXISTS `properties`;
CREATE TABLE IF NOT EXISTS `properties` (
  `id` varchar(16) NOT NULL,
  `value` varchar(256) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `properties`
--

INSERT INTO `properties` (`id`, `value`) VALUES
('alarm', '1460446103'),
('next_event', '0'),
('potd', 'tuesday'),
('round', '15'),
('startcash', '5000'),
('state', '2');

-- --------------------------------------------------------

--
-- Table structure for table `queue`
--

DROP TABLE IF EXISTS `queue`;
CREATE TABLE IF NOT EXISTS `queue` (
  `seq` int(11) NOT NULL,
  `datetime` varchar(19) DEFAULT NULL,
  `code` varchar(4) DEFAULT NULL,
  `action` varchar(4) DEFAULT NULL,
  `amount` int(2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `stocks`
--

DROP TABLE IF EXISTS `stocks`;
CREATE TABLE IF NOT EXISTS `stocks` (
  `code` varchar(4) NOT NULL DEFAULT '',
  `name` varchar(32) DEFAULT NULL,
  `category` varchar(1) DEFAULT NULL,
  `value` int(3) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `stocks`
--

INSERT INTO `stocks` (`code`, `name`, `category`, `value`) VALUES
('BOND', 'Bonds', 'B', 100),
('DHS', 'Donut Hole Syndicate', 'C', 100),
('GOOG', 'Google', 'A', 100),
('IXP', 'Inter-planetary Exploration Proj', 'C', 100),
('MLM', 'Moonlight madness', 'C', 100),
('MSFT', 'Microsoft', 'A', 100),
('PONZ', 'Ponzi Schemes R Us', 'C', 100),
('TECH', 'Technology', 'B', 100),
('TEL', 'Telus', 'A', 100);

-- --------------------------------------------------------

--
-- Table structure for table `transactions`
--

DROP TABLE IF EXISTS `transactions`;
CREATE TABLE IF NOT EXISTS `transactions` (
  `seq` int(11) NOT NULL,
  `datetime` varchar(19) DEFAULT NULL,
  `agent` varchar(4) NOT NULL,
  `player` varchar(6) DEFAULT NULL,
  `stock` varchar(4) DEFAULT NULL,
  `trans` varchar(4) DEFAULT NULL,
  `quantity` int(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `code` varchar(4) NOT NULL,
  `name` varchar(64) NOT NULL,
  `role` varchar(8) NOT NULL,
  `password` varchar(128) NOT NULL,
  `last_round` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `candidates`
--
ALTER TABLE `candidates`
  ADD PRIMARY KEY (`code`);

--
-- Indexes for table `certificates`
--
ALTER TABLE `certificates`
  ADD PRIMARY KEY (`token`);

--
-- Indexes for table `movement`
--
ALTER TABLE `movement`
  ADD PRIMARY KEY (`seq`);

--
-- Indexes for table `players`
--
ALTER TABLE `players`
  ADD PRIMARY KEY (`seq`);

--
-- Indexes for table `properties`
--
ALTER TABLE `properties`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `queue`
--
ALTER TABLE `queue`
  ADD PRIMARY KEY (`seq`);

--
-- Indexes for table `stocks`
--
ALTER TABLE `stocks`
  ADD PRIMARY KEY (`code`);

--
-- Indexes for table `transactions`
--
ALTER TABLE `transactions`
  ADD PRIMARY KEY (`seq`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`code`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `movement`
--
ALTER TABLE `movement`
  MODIFY `seq` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `players`
--
ALTER TABLE `players`
  MODIFY `seq` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `queue`
--
ALTER TABLE `queue`
  MODIFY `seq` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `transactions`
--
ALTER TABLE `transactions`
  MODIFY `seq` int(11) NOT NULL AUTO_INCREMENT;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
