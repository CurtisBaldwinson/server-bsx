-- phpMyAdmin SQL Dump
-- version 4.4.14.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Apr 13, 2016 at 02:07 AM
-- Server version: 5.6.26
-- PHP Version: 5.6.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `stockz`
--

-- --------------------------------------------------------

--
-- Table structure for table `candidates`
--

DROP TABLE IF EXISTS `candidates`;
CREATE TABLE IF NOT EXISTS `candidates` (
  `code` varchar(4) NOT NULL DEFAULT '',
  `name` varchar(32) DEFAULT NULL,
  `category` varchar(1) DEFAULT NULL,
  `value` int(3) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `candidates`
--

INSERT INTO `candidates` (`code`, `name`, `category`, `value`) VALUES
('APPL', 'Apple', 'A', 100),
('BOND', 'Bonds', 'B', 66),
('BP', 'Believable Products', 'C', 100),
('COFF', 'Coffee', 'C', 100),
('DHS', 'Donut Hole Syndicate', 'C', 100),
('DSC', 'Deathstar Construction', 'C', 100),
('EBD', 'Environmental Bio Diversity', 'C', 100),
('FBN', 'Fly-by-Night Business Network', 'C', 100),
('GMC', 'General Motors', 'A', 100),
('GOLD', 'Gold', 'B', 110),
('GOOG', 'Google', 'A', 100),
('GRAN', 'Grain', 'B', 113),
('HD', 'Harley Davidson', 'A', 100),
('IBM', 'IBM', 'A', 100),
('IND', 'Industrial', 'B', 39),
('IXP', 'Inter-planetary Exploration Proj', 'C', 100),
('MLM', 'Moonlight madness', 'C', 100),
('MSFT', 'Microsoft', 'A', 100),
('OIL', 'Oil', 'B', 52),
('PONZ', 'Ponzi Schemes R Us', 'C', 100),
('RUN', 'Rich Uncle', 'C', 100),
('SFA', 'Star Fleet Academy', 'C', 100),
('SMV', 'Smoke & Mirrors Ventures', 'C', 100),
('SSO', 'Sleezy Snake Oil Sales', 'C', 100),
('TECH', 'Technology', 'B', 37),
('TEL', 'Telus', 'A', 100);

-- --------------------------------------------------------

--
-- Table structure for table `certificates`
--

DROP TABLE IF EXISTS `certificates`;
CREATE TABLE IF NOT EXISTS `certificates` (
  `token` varchar(8) NOT NULL,
  `stock` varchar(4) NOT NULL,
  `agent` varchar(4) NOT NULL,
  `player` varchar(64) NOT NULL,
  `amount` int(11) NOT NULL,
  `datetime` varchar(19) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `movement`
--

DROP TABLE IF EXISTS `movement`;
CREATE TABLE IF NOT EXISTS `movement` (
  `seq` int(11) NOT NULL,
  `datetime` varchar(19) DEFAULT NULL,
  `code` varchar(4) DEFAULT NULL,
  `action` varchar(4) DEFAULT NULL,
  `amount` int(2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `players`
--

DROP TABLE IF EXISTS `players`;
CREATE TABLE IF NOT EXISTS `players` (
  `seq` int(11) NOT NULL,
  `agent` varchar(4) NOT NULL,
  `player` varchar(32) NOT NULL,
  `cash` int(11) NOT NULL,
  `round` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `properties`
--

DROP TABLE IF EXISTS `properties`;
CREATE TABLE IF NOT EXISTS `properties` (
  `id` varchar(16) NOT NULL,
  `value` varchar(256) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `properties`
--

INSERT INTO `properties` (`id`, `value`) VALUES
('alarm', '1460503341'),
('next_event', '0'),
('potd', 'tuesday'),
('round', '9'),
('startcash', '5000'),
('state', '2');

-- --------------------------------------------------------

--
-- Table structure for table `queue`
--

DROP TABLE IF EXISTS `queue`;
CREATE TABLE IF NOT EXISTS `queue` (
  `seq` int(11) NOT NULL,
  `datetime` varchar(19) DEFAULT NULL,
  `code` varchar(4) DEFAULT NULL,
  `action` varchar(4) DEFAULT NULL,
  `amount` int(2) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=570 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `queue`
--

INSERT INTO `queue` (`seq`, `datetime`, `code`, `action`, `amount`) VALUES
(1, '1460503324', 'GRAN', 'up', 10),
(2, '1460503325', 'DSC', 'down', 20),
(3, '1460503329', 'IBM', 'down', 10),
(4, '1460503329', 'FBN', 'down', 5),
(5, '1460503330', 'DSC', 'down', 5),
(6, '1460503331', 'OIL', 'up', 10),
(7, '1460503333', 'TEL', 'div', 20),
(8, '1460503333', 'GRAN', 'up', 5),
(9, '1460503333', 'DSC', 'div', 5),
(10, '1460503334', 'HD', 'div', 10),
(11, '1460503334', 'FBN', 'down', 10),
(12, '1460503335', 'FBN', 'up', 10),
(13, '1460503335', 'DSC', 'down', 5),
(14, '1460503336', 'FBN', 'up', 20),
(15, '1460503336', 'DSC', 'down', 20),
(16, '1460503336', 'FBN', 'down', 10),
(17, '1460503337', 'APPL', 'up', 5),
(18, '1460503338', 'APPL', 'div', 5),
(19, '1460503338', 'HD', 'up', 5),
(20, '1460503338', 'GRAN', 'up', 20),
(21, '1460503338', 'GRAN', 'down', 5),
(22, '1460503338', 'DSC', 'div', 20),
(23, '1460503338', 'DSC', 'down', 10),
(24, '1460503339', 'DSC', 'down', 5),
(25, '1460503339', 'FBN', 'up', 10),
(26, '1460503341', 'IBM', 'up', 10),
(27, '1460503341', 'OIL', 'down', 20),
(28, '1460503342', 'FBN', 'down', 10),
(29, '1460503343', 'DSC', 'up', 5),
(30, '1460503344', 'FBN', 'down', 5),
(31, '1460503345', 'FBN', 'up', 20),
(32, '1460503346', 'GRAN', 'down', 10),
(33, '1460503346', 'OIL', 'down', 10),
(34, '1460503346', 'FBN', 'down', 5),
(35, '1460503348', 'OIL', 'down', 20),
(36, '1460503349', 'TEL', 'down', 10),
(37, '1460503349', 'HD', 'up', 5),
(38, '1460503349', 'DSC', 'div', 5),
(39, '1460503350', 'TEL', 'up', 5),
(40, '1460503350', 'OIL', 'down', 10),
(41, '1460503350', 'DSC', 'div', 5),
(42, '1460503351', 'APPL', 'div', 10),
(43, '1460503351', 'FBN', 'up', 10),
(44, '1460503351', 'IBM', 'up', 5),
(45, '1460503352', 'IBM', 'up', 5),
(46, '1460503353', 'IBM', 'up', 10),
(47, '1460503353', 'FBN', 'down', 10),
(48, '1460503353', 'DSC', 'up', 10),
(49, '1460503353', 'GRAN', 'down', 20),
(50, '1460503353', 'FBN', 'div', 10),
(51, '1460503353', 'DSC', 'down', 5),
(52, '1460503354', 'OIL', 'down', 10),
(53, '1460503355', 'OIL', 'div', 20),
(54, '1460503356', 'GRAN', 'down', 20),
(55, '1460503356', 'FBN', 'div', 5),
(56, '1460503356', 'FBN', 'down', 20),
(57, '1460503357', 'OIL', 'down', 10),
(58, '1460503358', 'TEL', 'up', 20),
(59, '1460503358', 'DSC', 'down', 20),
(60, '1460503359', 'FBN', 'down', 5),
(61, '1460503360', 'DSC', 'down', 10),
(62, '1460503360', 'FBN', 'up', 10),
(63, '1460503360', 'FBN', 'down', 20),
(64, '1460503360', 'DSC', 'down', 20),
(65, '1460503361', 'DSC', 'up', 10),
(66, '1460503362', 'HD', 'up', 10),
(67, '1460503362', 'DSC', 'div', 5),
(68, '1460503363', 'IBM', 'up', 20),
(69, '1460503363', 'IBM', 'up', 5),
(70, '1460503363', 'FBN', 'div', 5),
(71, '1460503365', 'APPL', 'up', 10),
(72, '1460503365', 'OIL', 'div', 10),
(73, '1460503366', 'FBN', 'up', 5),
(74, '1460503366', 'FBN', 'down', 20),
(75, '1460503367', 'FBN', 'down', 20),
(76, '1460503368', 'DSC', 'down', 10),
(77, '1460503368', 'GRAN', 'div', 10),
(78, '1460503368', 'OIL', 'down', 10),
(79, '1460503368', 'FBN', 'up', 5),
(80, '1460503369', 'TEL', 'div', 10),
(81, '1460503369', 'GRAN', 'up', 20),
(82, '1460503369', 'FBN', 'up', 5),
(83, '1460503370', 'IBM', 'down', 10),
(84, '1460503371', 'IBM', 'up', 10),
(85, '1460503372', 'HD', 'up', 5),
(86, '1460503372', 'DSC', 'down', 20),
(87, '1460503372', 'DSC', 'down', 5),
(88, '1460503374', 'IBM', 'up', 20),
(89, '1460503374', 'TEL', 'up', 20),
(90, '1460503375', 'HD', 'div', 10),
(91, '1460503375', 'OIL', 'div', 20),
(92, '1460503376', 'APPL', 'up', 10),
(93, '1460503376', 'FBN', 'up', 10),
(94, '1460503376', 'FBN', 'down', 5),
(95, '1460503377', 'OIL', 'up', 20),
(96, '1460503378', 'OIL', 'up', 5),
(97, '1460503379', 'FBN', 'down', 5),
(98, '1460503379', 'FBN', 'up', 10),
(99, '1460503379', 'FBN', 'down', 5),
(100, '1460503380', 'DSC', 'up', 20),
(101, '1460503380', 'FBN', 'div', 20),
(102, '1460503380', 'DSC', 'up', 10),
(103, '1460503380', 'FBN', 'div', 20),
(104, '1460503380', 'FBN', 'down', 10),
(105, '1460503381', 'APPL', 'down', 10),
(106, '1460503381', 'FBN', 'up', 5),
(107, '1460503382', 'TEL', 'up', 5),
(108, '1460503382', 'FBN', 'up', 10),
(109, '1460503382', 'FBN', 'down', 10),
(110, '1460503382', 'FBN', 'down', 20),
(111, '1460503383', 'OIL', 'down', 10),
(112, '1460503384', 'DSC', 'up', 5),
(113, '1460503384', 'DSC', 'down', 5),
(114, '1460503384', 'FBN', 'up', 5),
(115, '1460503385', 'GRAN', 'div', 5),
(116, '1460503386', 'TEL', 'div', 5),
(117, '1460503386', 'DSC', 'down', 20),
(118, '1460503387', 'IBM', 'down', 20),
(119, '1460503388', 'IBM', 'up', 5),
(120, '1460503388', 'APPL', 'up', 10),
(121, '1460503388', 'GRAN', 'div', 5),
(122, '1460503389', 'FBN', 'down', 20),
(123, '1460503389', 'TEL', 'down', 10),
(124, '1460503389', 'FBN', 'up', 10),
(125, '1460503389', 'FBN', 'up', 20),
(126, '1460503391', 'FBN', 'down', 20),
(127, '1460503391', 'TEL', 'up', 10),
(128, '1460503391', 'DSC', 'down', 20),
(129, '1460503392', 'FBN', 'div', 5),
(130, '1460503392', 'OIL', 'up', 20),
(131, '1460503393', 'TEL', 'down', 5),
(132, '1460503393', 'DSC', 'down', 5),
(133, '1460503393', 'DSC', 'down', 10),
(134, '1460503394', 'DSC', 'up', 5),
(135, '1460503395', 'GRAN', 'down', 5),
(136, '1460503395', 'DSC', 'down', 5),
(137, '1460503396', 'GRAN', 'div', 10),
(138, '1460503397', 'HD', 'down', 10),
(139, '1460503397', 'DSC', 'up', 5),
(140, '1460503398', 'DSC', 'div', 10),
(141, '1460503399', 'HD', 'up', 20),
(142, '1460503400', 'GRAN', 'div', 10),
(143, '1460503400', 'GRAN', 'down', 10),
(144, '1460503401', 'HD', 'up', 10),
(145, '1460503401', 'FBN', 'div', 20),
(146, '1460503401', 'GRAN', 'up', 10),
(147, '1460503401', 'OIL', 'div', 20),
(148, '1460503401', 'DSC', 'down', 5),
(149, '1460503402', 'FBN', 'up', 10),
(150, '1460503402', 'OIL', 'div', 5),
(151, '1460503402', 'OIL', 'up', 5),
(152, '1460503402', 'OIL', 'up', 5),
(153, '1460503402', 'DSC', 'down', 10),
(154, '1460503403', 'GRAN', 'div', 20),
(155, '1460503404', 'DSC', 'up', 10),
(156, '1460503405', 'GRAN', 'up', 5),
(157, '1460503405', 'OIL', 'div', 5),
(158, '1460503405', 'GRAN', 'up', 20),
(159, '1460503405', 'DSC', 'down', 10),
(160, '1460503406', 'HD', 'up', 10),
(161, '1460503406', 'FBN', 'up', 10),
(162, '1460503408', 'FBN', 'down', 5),
(163, '1460503409', 'DSC', 'up', 5),
(164, '1460503409', 'FBN', 'up', 5),
(165, '1460503412', 'FBN', 'down', 20),
(166, '1460503413', 'DSC', 'div', 20),
(167, '1460503413', 'FBN', 'down', 10),
(168, '1460503414', 'TEL', 'up', 20),
(169, '1460503414', 'FBN', 'up', 10),
(170, '1460503415', 'OIL', 'div', 5),
(171, '1460503416', 'FBN', 'up', 20),
(172, '1460503416', 'OIL', 'up', 20),
(173, '1460503416', 'FBN', 'down', 20),
(174, '1460503416', 'FBN', 'up', 20),
(175, '1460503417', 'FBN', 'down', 10),
(176, '1460503418', 'DSC', 'div', 20),
(177, '1460503420', 'GRAN', 'down', 5),
(178, '1460503421', 'FBN', 'down', 20),
(179, '1460503422', 'FBN', 'up', 20),
(180, '1460503423', 'HD', 'down', 10),
(181, '1460503423', 'OIL', 'up', 20),
(182, '1460503424', 'IBM', 'div', 10),
(183, '1460503425', 'TEL', 'div', 20),
(184, '1460503426', 'OIL', 'div', 10),
(185, '1460503426', 'GRAN', 'div', 10),
(186, '1460503426', 'DSC', 'up', 5),
(187, '1460503429', 'OIL', 'div', 20),
(188, '1460503429', 'OIL', 'div', 10),
(189, '1460503429', 'DSC', 'down', 5),
(190, '1460503430', 'FBN', 'up', 10),
(191, '1460503431', 'APPL', 'up', 10),
(192, '1460503431', 'OIL', 'div', 20),
(193, '1460503431', 'DSC', 'down', 10),
(194, '1460503432', 'OIL', 'div', 20),
(195, '1460503432', 'FBN', 'down', 10),
(196, '1460503432', 'FBN', 'up', 20),
(197, '1460503433', 'OIL', 'div', 5),
(198, '1460503434', 'GRAN', 'up', 10),
(199, '1460503435', 'HD', 'up', 5),
(200, '1460503435', 'HD', 'div', 10),
(201, '1460503436', 'DSC', 'down', 5),
(202, '1460503437', 'OIL', 'up', 20),
(203, '1460503437', 'FBN', 'up', 10),
(204, '1460503438', 'OIL', 'div', 10),
(205, '1460503438', 'IBM', 'div', 5),
(206, '1460503438', 'FBN', 'up', 5),
(207, '1460503439', 'DSC', 'down', 10),
(208, '1460503440', 'DSC', 'div', 20),
(209, '1460503440', 'GRAN', 'div', 10),
(210, '1460503440', 'DSC', 'up', 5),
(211, '1460503441', 'FBN', 'up', 10),
(212, '1460503441', 'DSC', 'up', 20),
(213, '1460503442', 'DSC', 'up', 10),
(214, '1460503442', 'OIL', 'down', 20),
(215, '1460503442', 'FBN', 'down', 5),
(216, '1460503443', 'HD', 'up', 5),
(217, '1460503443', 'DSC', 'down', 10),
(218, '1460503444', 'DSC', 'up', 5),
(219, '1460503444', 'OIL', 'up', 5),
(220, '1460503444', 'DSC', 'div', 20),
(221, '1460503445', 'FBN', 'down', 10),
(222, '1460503446', 'DSC', 'up', 10),
(223, '1460503446', 'GRAN', 'div', 5),
(224, '1460503446', 'DSC', 'down', 5),
(225, '1460503448', 'GRAN', 'div', 20),
(226, '1460503449', 'DSC', 'up', 20),
(227, '1460503450', 'FBN', 'div', 10),
(228, '1460503452', 'TEL', 'up', 10),
(229, '1460503452', 'DSC', 'down', 5),
(230, '1460503452', 'DSC', 'down', 10),
(231, '1460503453', 'TEL', 'up', 20),
(232, '1460503453', 'GRAN', 'div', 10),
(233, '1460503453', 'DSC', 'down', 10),
(234, '1460503454', 'IBM', 'up', 10),
(235, '1460503454', 'TEL', 'up', 5),
(236, '1460503454', 'GRAN', 'div', 5),
(237, '1460503454', 'DSC', 'up', 5),
(238, '1460503455', 'GRAN', 'div', 10),
(239, '1460503455', 'GRAN', 'div', 5),
(240, '1460503455', 'OIL', 'down', 10),
(241, '1460503455', 'DSC', 'down', 10),
(242, '1460503459', 'APPL', 'div', 20),
(243, '1460503459', 'APPL', 'div', 10),
(244, '1460503459', 'FBN', 'up', 20),
(245, '1460503460', 'FBN', 'div', 10),
(246, '1460503461', 'FBN', 'up', 20),
(247, '1460503461', 'GRAN', 'div', 10),
(248, '1460503462', 'GRAN', 'up', 5),
(249, '1460503462', 'DSC', 'div', 20),
(250, '1460503462', 'FBN', 'up', 5),
(251, '1460503463', 'TEL', 'up', 5),
(252, '1460503463', 'DSC', 'down', 10),
(253, '1460503464', 'OIL', 'down', 20),
(254, '1460503464', 'FBN', 'down', 10),
(255, '1460503464', 'DSC', 'down', 10),
(256, '1460503465', 'IBM', 'div', 10),
(257, '1460503465', 'FBN', 'down', 10),
(258, '1460503466', 'OIL', 'up', 20),
(259, '1460503467', 'GRAN', 'div', 20),
(260, '1460503467', 'DSC', 'up', 10),
(261, '1460503467', 'DSC', 'down', 20),
(262, '1460503468', 'GRAN', 'up', 5),
(263, '1460503468', 'APPL', 'div', 5),
(264, '1460503469', 'FBN', 'down', 10),
(265, '1460503470', 'DSC', 'div', 5),
(266, '1460503470', 'FBN', 'div', 20),
(267, '1460503470', 'FBN', 'down', 20),
(268, '1460503471', 'HD', 'down', 5),
(269, '1460503471', 'DSC', 'up', 10),
(270, '1460503471', 'HD', 'up', 20),
(271, '1460503471', 'FBN', 'down', 5),
(272, '1460503471', 'DSC', 'up', 5),
(273, '1460503472', 'IBM', 'div', 20),
(274, '1460503472', 'DSC', 'up', 20),
(275, '1460503472', 'OIL', 'down', 10),
(276, '1460503473', 'GRAN', 'div', 10),
(277, '1460503473', 'FBN', 'up', 10),
(278, '1460503474', 'TEL', 'up', 5),
(279, '1460503474', 'DSC', 'up', 20),
(280, '1460503475', 'DSC', 'down', 5),
(281, '1460503475', 'DSC', 'down', 20),
(282, '1460503476', 'DSC', 'up', 5),
(283, '1460503476', 'GRAN', 'up', 10),
(284, '1460503477', 'DSC', 'down', 5),
(285, '1460503478', 'FBN', 'up', 20),
(286, '1460503479', 'DSC', 'up', 10),
(287, '1460503480', 'DSC', 'down', 10),
(288, '1460503480', 'APPL', 'div', 5),
(289, '1460503481', 'TEL', 'up', 5),
(290, '1460503481', 'IBM', 'div', 20),
(291, '1460503481', 'HD', 'div', 5),
(292, '1460503481', 'FBN', 'up', 20),
(293, '1460503481', 'FBN', 'div', 5),
(294, '1460503482', 'APPL', 'up', 20),
(295, '1460503482', 'APPL', 'up', 10),
(296, '1460503482', 'TEL', 'up', 20),
(297, '1460503482', 'FBN', 'div', 20),
(298, '1460503482', 'OIL', 'div', 20),
(299, '1460503483', 'OIL', 'down', 20),
(300, '1460503484', 'FBN', 'up', 10),
(301, '1460503484', 'TEL', 'up', 20),
(302, '1460503484', 'DSC', 'down', 10),
(303, '1460503485', 'GRAN', 'div', 5),
(304, '1460503486', 'FBN', 'up', 5),
(305, '1460503488', 'FBN', 'down', 10),
(306, '1460503488', 'OIL', 'div', 10),
(307, '1460503488', 'DSC', 'down', 10),
(308, '1460503489', 'IBM', 'up', 20),
(309, '1460503489', 'FBN', 'down', 20),
(310, '1460503489', 'OIL', 'div', 5),
(311, '1460503490', 'FBN', 'up', 10),
(312, '1460503491', 'APPL', 'div', 5),
(313, '1460503491', 'DSC', 'up', 10),
(314, '1460503492', 'GRAN', 'down', 5),
(315, '1460503493', 'APPL', 'div', 10),
(316, '1460503493', 'IBM', 'up', 20),
(317, '1460503493', 'DSC', 'up', 10),
(318, '1460503494', 'DSC', 'up', 5),
(319, '1460503494', 'TEL', 'up', 10),
(320, '1460503494', 'GRAN', 'down', 20),
(321, '1460503495', 'HD', 'down', 10),
(322, '1460503495', 'DSC', 'up', 5),
(323, '1460503495', 'FBN', 'div', 20),
(324, '1460503496', 'TEL', 'down', 10),
(325, '1460503497', 'FBN', 'div', 10),
(326, '1460503498', 'DSC', 'down', 10),
(327, '1460503498', 'FBN', 'up', 20),
(328, '1460503498', 'DSC', 'down', 10),
(329, '1460503498', 'FBN', 'down', 20),
(330, '1460503499', 'GRAN', 'up', 5),
(331, '1460503499', 'FBN', 'div', 10),
(332, '1460503499', 'FBN', 'up', 10),
(333, '1460503500', 'FBN', 'down', 20),
(334, '1460503501', 'IBM', 'up', 5),
(335, '1460503502', 'DSC', 'div', 10),
(336, '1460503504', 'FBN', 'up', 20),
(337, '1460503504', 'DSC', 'up', 20),
(338, '1460503504', 'DSC', 'up', 10),
(339, '1460503505', 'GRAN', 'down', 10),
(340, '1460503505', 'DSC', 'div', 10),
(341, '1460503505', 'FBN', 'up', 20),
(342, '1460503506', 'APPL', 'div', 10),
(343, '1460503506', 'DSC', 'div', 10),
(344, '1460503506', 'DSC', 'div', 5),
(345, '1460503507', 'FBN', 'up', 10),
(346, '1460503507', 'OIL', 'div', 10),
(347, '1460503508', 'FBN', 'down', 20),
(348, '1460503508', 'DSC', 'div', 5),
(349, '1460503509', 'DSC', 'up', 20),
(350, '1460503510', 'GRAN', 'div', 20),
(351, '1460503510', 'FBN', 'up', 5),
(352, '1460503510', 'FBN', 'up', 5),
(353, '1460503511', 'OIL', 'div', 10),
(354, '1460503511', 'GRAN', 'up', 10),
(355, '1460503512', 'OIL', 'up', 20),
(356, '1460503512', 'DSC', 'down', 10),
(357, '1460503514', 'APPL', 'div', 5),
(358, '1460503514', 'FBN', 'up', 5),
(359, '1460503515', 'DSC', 'up', 20),
(360, '1460503516', 'DSC', 'down', 20),
(361, '1460503517', 'FBN', 'down', 20),
(362, '1460503517', 'OIL', 'down', 10),
(363, '1460503517', 'DSC', 'down', 5),
(364, '1460503517', 'GRAN', 'down', 10),
(365, '1460503517', 'OIL', 'down', 5),
(366, '1460503518', 'DSC', 'up', 10),
(367, '1460503518', 'FBN', 'down', 20),
(368, '1460503519', 'APPL', 'down', 10),
(369, '1460503519', 'FBN', 'div', 20),
(370, '1460503520', 'GRAN', 'down', 5),
(371, '1460503520', 'DSC', 'down', 20),
(372, '1460503521', 'OIL', 'div', 10),
(373, '1460503521', 'HD', 'up', 20),
(374, '1460503521', 'TEL', 'down', 5),
(375, '1460503521', 'FBN', 'up', 10),
(376, '1460503522', 'FBN', 'div', 20),
(377, '1460503522', 'GRAN', 'down', 5),
(378, '1460503522', 'FBN', 'up', 10),
(379, '1460503522', 'DSC', 'down', 5),
(380, '1460503523', 'FBN', 'div', 5),
(381, '1460503524', 'FBN', 'up', 5),
(382, '1460503525', 'IBM', 'div', 5),
(383, '1460503525', 'GRAN', 'down', 20),
(384, '1460503526', 'DSC', 'div', 5),
(385, '1460503526', 'GRAN', 'up', 20),
(386, '1460503527', 'GRAN', 'div', 10),
(387, '1460503528', 'IBM', 'up', 5),
(388, '1460503529', 'FBN', 'down', 10),
(389, '1460503531', 'HD', 'div', 20),
(390, '1460503531', 'GRAN', 'up', 20),
(391, '1460503531', 'DSC', 'div', 5),
(392, '1460503532', 'FBN', 'up', 10),
(393, '1460503533', 'DSC', 'down', 20),
(394, '1460503534', 'DSC', 'down', 20),
(395, '1460503534', 'DSC', 'up', 5),
(396, '1460503535', 'GRAN', 'div', 10),
(397, '1460503535', 'DSC', 'down', 20),
(398, '1460503536', 'FBN', 'div', 20),
(399, '1460503537', 'HD', 'div', 5),
(400, '1460503537', 'DSC', 'down', 20),
(401, '1460503538', 'GRAN', 'down', 10),
(402, '1460503538', 'FBN', 'down', 20),
(403, '1460503539', 'HD', 'div', 10),
(404, '1460503539', 'TEL', 'div', 20),
(405, '1460503539', 'DSC', 'div', 5),
(406, '1460503539', 'DSC', 'down', 20),
(407, '1460503539', 'FBN', 'div', 5),
(408, '1460503540', 'FBN', 'up', 10),
(409, '1460503541', 'DSC', 'down', 5),
(410, '1460503542', 'HD', 'up', 20),
(411, '1460503542', 'GRAN', 'up', 10),
(412, '1460503542', 'OIL', 'down', 10),
(413, '1460503542', 'DSC', 'down', 10),
(414, '1460503543', 'FBN', 'up', 10),
(415, '1460503543', 'DSC', 'div', 5),
(416, '1460503544', 'FBN', 'up', 5),
(417, '1460503545', 'APPL', 'up', 5),
(418, '1460503546', 'FBN', 'down', 5),
(419, '1460503546', 'GRAN', 'down', 5),
(420, '1460503547', 'FBN', 'div', 5),
(421, '1460503547', 'GRAN', 'div', 20),
(422, '1460503547', 'GRAN', 'down', 20),
(423, '1460503547', 'DSC', 'down', 10),
(424, '1460503548', 'DSC', 'down', 20),
(425, '1460503549', 'IBM', 'down', 10),
(426, '1460503549', 'DSC', 'up', 5),
(427, '1460503549', 'FBN', 'up', 20),
(428, '1460503550', 'FBN', 'up', 20),
(429, '1460503550', 'OIL', 'up', 20),
(430, '1460503550', 'FBN', 'down', 5),
(431, '1460503550', 'DSC', 'div', 10),
(432, '1460503551', 'DSC', 'div', 5),
(433, '1460503551', 'DSC', 'down', 20),
(434, '1460503552', 'DSC', 'down', 20),
(435, '1460503552', 'APPL', 'up', 10),
(436, '1460503552', 'FBN', 'div', 10),
(437, '1460503553', 'TEL', 'div', 5),
(438, '1460503553', 'DSC', 'div', 5),
(439, '1460503553', 'FBN', 'div', 20),
(440, '1460503553', 'FBN', 'up', 10),
(441, '1460503553', 'DSC', 'down', 10),
(442, '1460503555', 'OIL', 'up', 10),
(443, '1460503556', 'OIL', 'down', 10),
(444, '1460503556', 'IBM', 'div', 5),
(445, '1460503557', 'GRAN', 'down', 20),
(446, '1460503557', 'HD', 'up', 5),
(447, '1460503557', 'GRAN', 'div', 5),
(448, '1460503557', 'FBN', 'up', 20),
(449, '1460503558', 'OIL', 'div', 20),
(450, '1460503560', 'OIL', 'down', 20),
(451, '1460503560', 'DSC', 'up', 20),
(452, '1460503561', 'OIL', 'up', 10),
(453, '1460503561', 'GRAN', 'up', 5),
(454, '1460503562', 'DSC', 'up', 5),
(455, '1460503562', 'FBN', 'up', 20),
(456, '1460503564', 'OIL', 'up', 5),
(457, '1460503565', 'DSC', 'up', 20),
(458, '1460503565', 'GRAN', 'div', 10),
(459, '1460503566', 'DSC', 'div', 5),
(460, '1460503567', 'OIL', 'div', 5),
(461, '1460503567', 'OIL', 'down', 20),
(462, '1460503567', 'DSC', 'up', 10),
(463, '1460503569', 'APPL', 'div', 5),
(464, '1460503570', 'FBN', 'div', 10),
(465, '1460503571', 'OIL', 'up', 10),
(466, '1460503571', 'DSC', 'down', 5),
(467, '1460503572', 'HD', 'down', 20),
(468, '1460503572', 'FBN', 'up', 20),
(469, '1460503573', 'GRAN', 'up', 10),
(470, '1460503574', 'IBM', 'up', 20),
(471, '1460503574', 'GRAN', 'div', 5),
(472, '1460503575', 'DSC', 'down', 5),
(473, '1460503575', 'DSC', 'div', 20),
(474, '1460503576', 'TEL', 'down', 20),
(475, '1460503577', 'DSC', 'down', 20),
(476, '1460503577', 'OIL', 'down', 5),
(477, '1460503577', 'DSC', 'up', 5),
(478, '1460503578', 'OIL', 'up', 20),
(479, '1460503579', 'DSC', 'div', 5),
(480, '1460503579', 'FBN', 'down', 20),
(481, '1460503579', 'FBN', 'up', 10),
(482, '1460503580', 'DSC', 'down', 5),
(483, '1460503581', 'OIL', 'down', 5),
(484, '1460503581', 'HD', 'up', 5),
(485, '1460503581', 'FBN', 'up', 5),
(486, '1460503581', 'DSC', 'down', 5),
(487, '1460503581', 'FBN', 'up', 5),
(488, '1460503582', 'OIL', 'div', 5),
(489, '1460503582', 'DSC', 'div', 20),
(490, '1460503582', 'DSC', 'down', 5),
(491, '1460503583', 'OIL', 'down', 10),
(492, '1460503583', 'IBM', 'up', 5),
(493, '1460503583', 'GRAN', 'down', 5),
(494, '1460503584', 'GRAN', 'div', 10),
(495, '1460503584', 'GRAN', 'up', 5),
(496, '1460503585', 'FBN', 'div', 5),
(497, '1460503587', 'HD', 'up', 20),
(498, '1460503587', 'DSC', 'div', 20),
(499, '1460503587', 'DSC', 'up', 5),
(500, '1460503589', 'HD', 'up', 5),
(501, '1460503589', 'FBN', 'down', 20),
(502, '1460503590', 'OIL', 'div', 10),
(503, '1460503591', 'APPL', 'div', 5),
(504, '1460503593', 'GRAN', 'div', 5),
(505, '1460503593', 'OIL', 'down', 10),
(506, '1460503594', 'TEL', 'up', 5),
(507, '1460503594', 'APPL', 'div', 20),
(508, '1460503594', 'GRAN', 'down', 10),
(509, '1460503594', 'FBN', 'div', 5),
(510, '1460503594', 'DSC', 'up', 20),
(511, '1460503595', 'GRAN', 'up', 20),
(512, '1460503595', 'FBN', 'up', 20),
(513, '1460503596', 'IBM', 'up', 5),
(514, '1460503596', 'DSC', 'down', 10),
(515, '1460503596', 'OIL', 'div', 10),
(516, '1460503596', 'OIL', 'down', 20),
(517, '1460503597', 'TEL', 'up', 20),
(518, '1460503597', 'FBN', 'up', 20),
(519, '1460503597', 'OIL', 'div', 20),
(520, '1460503597', 'DSC', 'down', 20),
(521, '1460503598', 'FBN', 'down', 20),
(522, '1460503600', 'OIL', 'up', 20),
(523, '1460503600', 'DSC', 'down', 5),
(524, '1460503600', 'OIL', 'down', 20),
(525, '1460503601', 'HD', 'up', 20),
(526, '1460503601', 'APPL', 'up', 10),
(527, '1460503601', 'FBN', 'down', 5),
(528, '1460503602', 'OIL', 'up', 10),
(529, '1460503602', 'DSC', 'up', 5),
(530, '1460503602', 'GRAN', 'div', 20),
(531, '1460503602', 'FBN', 'down', 10),
(532, '1460503602', 'FBN', 'up', 5),
(533, '1460503604', 'IBM', 'div', 20),
(534, '1460503604', 'APPL', 'up', 5),
(535, '1460503605', 'FBN', 'down', 20),
(536, '1460503605', 'OIL', 'div', 10),
(537, '1460503605', 'DSC', 'div', 5),
(538, '1460503605', 'GRAN', 'down', 20),
(539, '1460503605', 'OIL', 'down', 20),
(540, '1460503606', 'APPL', 'div', 20),
(541, '1460503606', 'FBN', 'down', 20),
(542, '1460503606', 'OIL', 'up', 10),
(543, '1460503606', 'GRAN', 'down', 5),
(544, '1460503606', 'DSC', 'div', 10),
(545, '1460503607', 'IBM', 'down', 10),
(546, '1460503607', 'APPL', 'div', 5),
(547, '1460503608', 'APPL', 'down', 10),
(548, '1460503608', 'DSC', 'up', 5),
(549, '1460503609', 'GRAN', 'div', 10),
(550, '1460503610', 'FBN', 'down', 5),
(551, '1460503611', 'FBN', 'up', 10),
(552, '1460503611', 'FBN', 'down', 10),
(553, '1460503611', 'DSC', 'up', 10),
(554, '1460503612', 'FBN', 'up', 5),
(555, '1460503612', 'FBN', 'down', 10),
(556, '1460503614', 'DSC', 'up', 10),
(557, '1460503614', 'DSC', 'up', 20),
(558, '1460503614', 'FBN', 'down', 10),
(559, '1460503615', 'APPL', 'div', 20),
(560, '1460503616', 'DSC', 'up', 10),
(561, '1460503617', 'FBN', 'div', 5),
(562, '1460503618', 'GRAN', 'up', 5),
(563, '1460503618', 'GRAN', 'div', 20),
(564, '1460503618', 'FBN', 'down', 20),
(565, '1460503620', 'DSC', 'down', 10),
(566, '1460503621', 'OIL', 'div', 10),
(567, '1460503622', 'TEL', 'up', 20),
(568, '1460503622', 'GRAN', 'up', 5),
(569, '1460503624', 'GRAN', 'down', 5);

-- --------------------------------------------------------

--
-- Table structure for table `stocks`
--

DROP TABLE IF EXISTS `stocks`;
CREATE TABLE IF NOT EXISTS `stocks` (
  `code` varchar(4) NOT NULL DEFAULT '',
  `name` varchar(32) DEFAULT NULL,
  `category` varchar(1) DEFAULT NULL,
  `value` int(3) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `stocks`
--

INSERT INTO `stocks` (`code`, `name`, `category`, `value`) VALUES
('APPL', 'Apple', 'A', 100),
('DSC', 'Deathstar Construction', 'C', 100),
('FBN', 'Fly-by-Night Business Network', 'C', 100),
('GRAN', 'Grain', 'B', 100),
('HD', 'Harley Davidson', 'A', 100),
('IBM', 'IBM', 'A', 100),
('OIL', 'Oil', 'B', 100),
('TEL', 'Telus', 'A', 100);

-- --------------------------------------------------------

--
-- Table structure for table `transactions`
--

DROP TABLE IF EXISTS `transactions`;
CREATE TABLE IF NOT EXISTS `transactions` (
  `seq` int(11) NOT NULL,
  `datetime` varchar(19) DEFAULT NULL,
  `agent` varchar(4) NOT NULL,
  `player` varchar(6) DEFAULT NULL,
  `stock` varchar(4) DEFAULT NULL,
  `trans` varchar(4) DEFAULT NULL,
  `quantity` int(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `code` varchar(4) NOT NULL,
  `name` varchar(64) NOT NULL,
  `role` varchar(8) NOT NULL,
  `password` varchar(128) NOT NULL,
  `last_round` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`code`, `name`, `role`, `password`, `last_round`) VALUES
('o99', 'Jim', 'agent', 'd2c794d60775c957c9cae3a5bc2f5471', 9);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `candidates`
--
ALTER TABLE `candidates`
  ADD PRIMARY KEY (`code`);

--
-- Indexes for table `certificates`
--
ALTER TABLE `certificates`
  ADD PRIMARY KEY (`token`);

--
-- Indexes for table `movement`
--
ALTER TABLE `movement`
  ADD PRIMARY KEY (`seq`);

--
-- Indexes for table `players`
--
ALTER TABLE `players`
  ADD PRIMARY KEY (`seq`);

--
-- Indexes for table `properties`
--
ALTER TABLE `properties`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `queue`
--
ALTER TABLE `queue`
  ADD PRIMARY KEY (`seq`);

--
-- Indexes for table `stocks`
--
ALTER TABLE `stocks`
  ADD PRIMARY KEY (`code`);

--
-- Indexes for table `transactions`
--
ALTER TABLE `transactions`
  ADD PRIMARY KEY (`seq`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`code`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `movement`
--
ALTER TABLE `movement`
  MODIFY `seq` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `players`
--
ALTER TABLE `players`
  MODIFY `seq` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `queue`
--
ALTER TABLE `queue`
  MODIFY `seq` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=570;
--
-- AUTO_INCREMENT for table `transactions`
--
ALTER TABLE `transactions`
  MODIFY `seq` int(11) NOT NULL AUTO_INCREMENT;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
